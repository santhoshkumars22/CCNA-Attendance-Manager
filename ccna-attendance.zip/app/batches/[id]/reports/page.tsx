"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronLeft, FileSpreadsheet } from "lucide-react"

export default function ReportsPage({ params }: { params: { id: string } }) {
  const [reportType, setReportType] = useState("weekly")
  const [period, setPeriod] = useState("current")

  // Sample data for demonstration
  const attendanceData = [
    { date: "2023-07-03", present: 18, absent: 6, percentage: "75%" },
    { date: "2023-07-04", present: 20, absent: 4, percentage: "83%" },
    { date: "2023-07-05", present: 22, absent: 2, percentage: "92%" },
    { date: "2023-07-06", present: 19, absent: 5, percentage: "79%" },
    { date: "2023-07-07", present: 21, absent: 3, percentage: "88%" },
  ]

  const studentData = [
    { id: 1, name: "John Doe", totalClasses: 24, attended: 22, percentage: "92%" },
    { id: 2, name: "Jane Smith", totalClasses: 24, attended: 20, percentage: "83%" },
    { id: 3, name: "Robert Johnson", totalClasses: 24, attended: 18, percentage: "75%" },
    { id: 4, name: "Emily Davis", totalClasses: 24, attended: 23, percentage: "96%" },
    { id: 5, name: "Michael Wilson", totalClasses: 24, attended: 19, percentage: "79%" },
  ]

  const generateReport = () => {
    // This would be handled by the backend
    console.log("Generating report:", { reportType, period })
    // The report would be generated and downloaded
  }

  const downloadReport = () => {
    // This would be handled by the backend
    console.log("Downloading report as Excel")
    // The Excel file would be downloaded
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">CCNA Batch {params.id} - Reports</h1>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Generate Attendance Report</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-2 block text-sm font-medium">Report Type</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Weekly Report</SelectItem>
                  <SelectItem value="monthly">Monthly Report</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium">Period</label>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">Current Week/Month</SelectItem>
                  <SelectItem value="previous">Previous Week/Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button onClick={generateReport}>Generate Report</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Attendance Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="summary">
            <TabsList className="mb-4">
              <TabsTrigger value="summary">Summary</TabsTrigger>
              <TabsTrigger value="students">By Student</TabsTrigger>
            </TabsList>

            <TabsContent value="summary">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Present</TableHead>
                      <TableHead>Absent</TableHead>
                      <TableHead>Attendance %</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attendanceData.map((day) => (
                      <TableRow key={day.date}>
                        <TableCell>{day.date}</TableCell>
                        <TableCell>{day.present}</TableCell>
                        <TableCell>{day.absent}</TableCell>
                        <TableCell>{day.percentage}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="students">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student Name</TableHead>
                      <TableHead>Total Classes</TableHead>
                      <TableHead>Classes Attended</TableHead>
                      <TableHead>Attendance %</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {studentData.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell>{student.totalClasses}</TableCell>
                        <TableCell>{student.attended}</TableCell>
                        <TableCell>{student.percentage}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-6 flex justify-end">
            <Button variant="outline" className="gap-2" onClick={downloadReport}>
              <FileSpreadsheet className="h-4 w-4" />
              Download as Excel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
