"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { ChevronLeft, Users, Calendar, FileText, AlertTriangle, CheckCircle2 } from "lucide-react"

export default function BatchDetailsPage({ params }: { params: { id: string } }) {
  const [isCompleted, setIsCompleted] = useState(false)

  // Sample batch data for demonstration
  const batch = {
    id: params.id,
    name: `CCNA Batch ${params.id}`,
    startDate: "2023-05-15",
    endDate: "2023-08-15",
    sessionTime: "Morning Session (8:00 AM - 10:00 AM)",
    progress: 65,
    studentCount: 24,
  }

  const handleMarkAsCompleted = () => {
    // This would be handled by the backend
    console.log("Marking batch as completed:", batch.id)
    setIsCompleted(true)
  }

  const handleDeleteBatch = () => {
    // This would be handled by the backend
    console.log("Deleting batch:", batch.id)
    // Redirect would happen here
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">{batch.name}</h1>
            {isCompleted && (
              <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                <CheckCircle2 className="mr-1 h-3 w-3" />
                Completed
              </span>
            )}
          </div>
          <p className="text-muted-foreground">{batch.sessionTime}</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <Link href={`/batches/${params.id}/students`}>
            <Button variant="outline" className="gap-2">
              <Users className="h-4 w-4" />
              Manage Students
            </Button>
          </Link>

          <Link href={`/batches/${params.id}/attendance`}>
            <Button variant="outline" className="gap-2">
              <Calendar className="h-4 w-4" />
              Take Attendance
            </Button>
          </Link>

          <Link href={`/batches/${params.id}/reports`}>
            <Button variant="outline" className="gap-2">
              <FileText className="h-4 w-4" />
              Reports
            </Button>
          </Link>
        </div>
      </div>

      {isCompleted && (
        <Alert className="mb-6">
          <CheckCircle2 className="h-4 w-4" />
          <AlertTitle>Batch Completed</AlertTitle>
          <AlertDescription>
            This batch has been marked as completed. You can still access all records and reports.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Batch Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                <p>{batch.startDate}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">End Date</p>
                <p>{batch.endDate}</p>
              </div>
            </div>

            <Separator />

            <div>
              <p className="text-sm font-medium text-muted-foreground">Session Time</p>
              <p>{batch.sessionTime}</p>
            </div>

            <Separator />

            <div>
              <div className="mb-1 flex justify-between text-sm">
                <span className="font-medium">Progress</span>
                <span>{batch.progress}%</span>
              </div>
              <Progress value={batch.progress} className="h-2" />
            </div>

            <Separator />

            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-muted-foreground" />
              <span>{batch.studentCount} students enrolled</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Batch Actions</CardTitle>
            <CardDescription>Manage the status of this batch</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isCompleted ? (
              <div className="rounded-lg border border-dashed p-4">
                <h3 className="mb-1 font-semibold">Mark as Completed</h3>
                <p className="mb-4 text-sm text-muted-foreground">
                  When the batch is over, mark it as completed to archive it.
                </p>
                <Button onClick={handleMarkAsCompleted}>Mark as Completed</Button>
              </div>
            ) : (
              <div className="rounded-lg border border-dashed p-4">
                <h3 className="mb-1 font-semibold">Batch Completed</h3>
                <p className="text-sm text-muted-foreground">
                  This batch has been marked as completed on {new Date().toLocaleDateString()}.
                </p>
              </div>
            )}

            <div className="rounded-lg border border-dashed border-red-200 bg-red-50 p-4">
              <h3 className="mb-1 font-semibold text-red-700">Delete Batch</h3>
              <p className="mb-4 text-sm text-red-600">
                This action cannot be undone. It will permanently delete the batch and all associated data.
              </p>

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="destructive">Delete Batch</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Are you sure?</DialogTitle>
                    <DialogDescription>
                      This action cannot be undone. This will permanently delete the batch and all associated student
                      records and attendance data.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="flex items-center gap-2 rounded-lg bg-amber-50 p-3 text-amber-800">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    <p className="text-sm">We recommend generating a report before deleting this batch.</p>
                  </div>
                  <DialogFooter>
                    <Link href={`/batches/${params.id}/reports`}>
                      <Button variant="outline">Generate Report First</Button>
                    </Link>
                    <Button variant="destructive" onClick={handleDeleteBatch}>
                      Yes, Delete Batch
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
