"use client"

import { useState, useCallback } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CalendarIcon, ChevronLeft, Save } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { useSocket, useAttendanceUpdates } from "@/lib/socket"
import { useToast } from "@/components/ui/use-toast"
import ActiveUsersIndicator from "@/components/active-users-indicator"

export default function AttendancePage({ params }: { params: { id: string } }) {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [students, setStudents] = useState([
    { id: 1, name: "John Doe", present: true },
    { id: 2, name: "Jane Smith", present: true },
    { id: 3, name: "Robert Johnson", present: false },
    { id: 4, name: "Emily Davis", present: true },
    { id: 5, name: "Michael Wilson", present: false },
  ])
  const [recentlyUpdated, setRecentlyUpdated] = useState<number | null>(null)
  const { emitAttendanceChange, isConnected } = useSocket()
  const { toast } = useToast()

  // Handle incoming attendance updates from other users
  const handleAttendanceUpdates = useCallback(
    (updatedStudents: any[]) => {
      setStudents(updatedStudents)
      toast({
        title: "Attendance Updated",
        description: "Another user has updated the attendance records.",
        duration: 3000,
      })
    },
    [toast],
  )

  // Subscribe to attendance updates for this batch
  useAttendanceUpdates(params.id, students, handleAttendanceUpdates)

  const toggleAttendance = (id: number) => {
    const updatedStudents = students.map((student) =>
      student.id === id ? { ...student, present: !student.present } : student,
    )

    setStudents(updatedStudents)
    setRecentlyUpdated(id)

    // Clear the highlight after animation
    setTimeout(() => setRecentlyUpdated(null), 2000)

    // Emit the change to other users
    const updatedStudent = updatedStudents.find((s) => s.id === id)
    if (updatedStudent) {
      emitAttendanceChange(params.id, id, updatedStudent.present)
    }
  }

  const markAllPresent = () => {
    const updatedStudents = students.map((student) => ({ ...student, present: true }))
    setStudents(updatedStudents)

    // Emit the change to other users
    emitAttendanceChange(params.id, -1, true) // -1 indicates all students
  }

  const markAllAbsent = () => {
    const updatedStudents = students.map((student) => ({ ...student, present: false }))
    setStudents(updatedStudents)

    // Emit the change to other users
    emitAttendanceChange(params.id, -1, false) // -1 indicates all students
  }

  const saveAttendance = () => {
    // This would be handled by the backend
    console.log("Saving attendance for date:", date)
    console.log("Student attendance:", students)

    toast({
      title: "Attendance Saved",
      description: `Attendance for ${format(date || new Date(), "PPP")} has been saved.`,
      duration: 3000,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <Link href="/" className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Dashboard
        </Link>

        <ActiveUsersIndicator />
      </div>

      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold">CCNA Batch {params.id} - Attendance</h1>

        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="gap-2">
                <CalendarIcon className="h-4 w-4" />
                {date ? format(date, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Mark Attendance</CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={markAllPresent}>
              Mark All Present
            </Button>
            <Button variant="outline" size="sm" onClick={markAllAbsent}>
              Mark All Absent
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {!isConnected && (
            <div className="mb-4 rounded-md bg-yellow-50 p-3 text-yellow-800">
              <p className="text-sm">
                You are currently offline. Changes will be saved locally and synced when you reconnect.
              </p>
            </div>
          )}

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student Name</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.map((student) => (
                <TableRow
                  key={student.id}
                  className={recentlyUpdated === student.id ? "bg-blue-50 transition-colors duration-1000" : ""}
                >
                  <TableCell className="font-medium">{student.name}</TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex rounded-full px-2 py-1 text-xs font-medium cursor-pointer hover:opacity-80 transition-all ${
                        student.present ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                      onClick={() => toggleAttendance(student.id)}
                    >
                      {student.present ? "Present" : "Absent"}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <div className="mt-6 flex justify-end">
            <Button className="gap-2" onClick={saveAttendance}>
              <Save className="h-4 w-4" />
              Save Attendance
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
