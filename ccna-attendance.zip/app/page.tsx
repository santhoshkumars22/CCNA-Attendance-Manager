"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Users, ArrowUpDown } from "lucide-react"
import BatchModal from "@/components/batch-modal"

export default function Dashboard() {
  const [selectedBatch, setSelectedBatch] = useState<{
    id: string
    name: string
    sessionTime: string
    startDate: string
    endDate: string
    instructor: string
  } | null>(null)

  const batches = [
    {
      id: "1",
      name: "CCNA Batch 1",
      sessionTime: "Morning Session (8:00 AM - 10:00 AM)",
      startDate: "May 15, 2023",
      endDate: "Aug 15, 2023",
      instructor: "John Doe",
      progress: 65,
      students: 24,
    },
    {
      id: "2",
      name: "CCNA Batch 2",
      sessionTime: "Evening Session (6:00 PM - 8:00 PM)",
      startDate: "Jun 1, 2023",
      endDate: "Sep 1, 2023",
      instructor: "Jane Smith",
      progress: 40,
      students: 18,
    },
  ]

  const openBatchModal = (batch: (typeof batches)[0]) => {
    setSelectedBatch({
      id: batch.id,
      name: batch.name,
      sessionTime: batch.sessionTime,
      startDate: batch.startDate,
      endDate: batch.endDate,
      instructor: batch.instructor,
    })
  }

  const closeBatchModal = () => {
    setSelectedBatch(null)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 bg-blue-600 text-white">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <h1 className="text-2xl font-bold">CCNA Attendance Manager</h1>
          <Link href="/batches/new">
            <Button variant="secondary" className="font-medium">
              Create New Batch
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 bg-slate-50">
        <div className="container mx-auto px-4 py-6">
          {/* Stats Overview */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Batches</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">2</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-green-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Students</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">42</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Attendance Today</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">85%</div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filters */}
          <div className="mt-6 rounded-lg bg-white p-4 shadow-sm">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="relative flex-1">
                <Input type="search" placeholder="Search batches..." className="pl-10 pr-4" />
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <svg
                    className="w-4 h-4 text-gray-500"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                </div>
              </div>

              <div className="flex gap-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Batches" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Batches</SelectItem>
                    <SelectItem value="active">Active Batches</SelectItem>
                    <SelectItem value="completed">Completed Batches</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline" className="gap-2">
                  <ArrowUpDown className="h-4 w-4" />
                  <span>Sort</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Batches List */}
          <h2 className="mt-8 mb-4 text-2xl font-bold">Your CCNA Batches</h2>

          <div className="grid gap-6 md:grid-cols-2">
            {batches.map((batch) => (
              <Card
                key={batch.id}
                className="cursor-pointer hover:shadow-md hover:border-blue-200 transition-all"
                onClick={() => openBatchModal(batch)}
              >
                <CardContent className="p-6">
                  <div className="flex justify-between">
                    <div>
                      <div className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                        Active
                      </div>
                      <h3 className="mt-2 text-xl font-bold">{batch.name}</h3>
                      <p className="text-muted-foreground">{batch.sessionTime}</p>
                    </div>
                    <div className="text-right text-sm">
                      <p>Started: {batch.startDate}</p>
                      <p>Ends: {batch.endDate}</p>
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="mb-1 flex justify-between text-sm">
                      <span>Progress</span>
                      <span className="font-medium">{batch.progress}%</span>
                    </div>
                    <Progress value={batch.progress} className="h-2" />
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-muted-foreground" />
                      <span>{batch.students} students</span>
                    </div>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation()
                        window.location.href = `/batches/${batch.id}/attendance`
                      }}
                    >
                      Take Attendance
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>

      {/* Batch Modal */}
      {selectedBatch && (
        <BatchModal
          batchId={selectedBatch.id}
          batchName={selectedBatch.name}
          sessionTime={selectedBatch.sessionTime}
          startDate={selectedBatch.startDate}
          endDate={selectedBatch.endDate}
          instructor={selectedBatch.instructor}
          isOpen={!!selectedBatch}
          onClose={closeBatchModal}
        />
      )}
    </div>
  )
}
