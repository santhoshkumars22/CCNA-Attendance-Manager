"use client"

import { io, type Socket } from "socket.io-client"
import { useState, useEffect } from "react"

// This will store our socket instance
let socket: Socket | null = null

export const useSocket = () => {
  const [isConnected, setIsConnected] = useState(false)
  const [activeUsers, setActiveUsers] = useState<{ id: string; name: string }[]>([])

  useEffect(() => {
    // Initialize socket connection if it doesn't exist
    if (!socket) {
      // In production, you'd use your deployed URL
      socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:3001", {
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
      })
    }

    // Set up event listeners
    socket.on("connect", () => {
      console.log("Socket connected")
      setIsConnected(true)

      // Join with a user name (in a real app, this would be from authentication)
      const userName = localStorage.getItem("userName") || `User-${Math.floor(Math.random() * 1000)}`
      socket.emit("user:join", { name: userName })
    })

    socket.on("disconnect", () => {
      console.log("Socket disconnected")
      setIsConnected(false)
    })

    socket.on("users:update", (users) => {
      setActiveUsers(users)
    })

    // Clean up on unmount
    return () => {
      if (socket) {
        socket.off("connect")
        socket.off("disconnect")
        socket.off("users:update")
      }
    }
  }, [])

  // Function to emit attendance changes
  const emitAttendanceChange = (batchId: string, studentId: number, isPresent: boolean) => {
    if (socket && isConnected) {
      socket.emit("attendance:update", { batchId, studentId, isPresent })
    }
  }

  // Function to emit batch data changes
  const emitBatchUpdate = (batchId: string, data: any) => {
    if (socket && isConnected) {
      socket.emit("batch:update", { batchId, data })
    }
  }

  return {
    socket,
    isConnected,
    activeUsers,
    emitAttendanceChange,
    emitBatchUpdate,
  }
}

// Subscribe to specific attendance updates for a batch
export const useAttendanceUpdates = (batchId: string, initialData: any[], callback: (data: any[]) => void) => {
  useEffect(() => {
    if (!socket) return

    // Listen for attendance updates for this specific batch
    const handleAttendanceUpdate = (data: { batchId: string; updates: any[] }) => {
      if (data.batchId === batchId) {
        callback(data.updates)
      }
    }

    socket.on("attendance:updated", handleAttendanceUpdate)

    return () => {
      socket.off("attendance:updated", handleAttendanceUpdate)
    }
  }, [batchId, callback])
}
