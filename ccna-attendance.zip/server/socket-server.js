// This would be a separate Node.js server in production
// For demonstration purposes only

const { Server } = require("socket.io")
const http = require("http")
const express = require("express")

const app = express()
const server = http.createServer(app)
const io = new Server(server, {
  cors: {
    origin: "*", // In production, restrict this to your domain
    methods: ["GET", "POST"],
  },
})

// Store connected users
const users = new Map()
// Store batch data
const batchData = new Map()

io.on("connection", (socket) => {
  console.log("User connected:", socket.id)

  // Handle user joining
  socket.on("user:join", ({ name }) => {
    users.set(socket.id, { id: socket.id, name })

    // Broadcast updated user list to all clients
    io.emit("users:update", Array.from(users.values()))
  })

  // Handle attendance updates
  socket.on("attendance:update", ({ batchId, studentId, isPresent }) => {
    console.log(`Attendance update for batch ${batchId}, student ${studentId}: ${isPresent}`)

    // Get current batch data or initialize if not exists
    const currentBatchData = batchData.get(batchId) || {
      students: [],
    }

    // Update student attendance
    if (studentId === -1) {
      // Mark all students
      currentBatchData.students = currentBatchData.students.map((student) => ({
        ...student,
        present: isPresent,
      }))
    } else {
      // Update specific student
      const studentIndex = currentBatchData.students.findIndex((s) => s.id === studentId)

      if (studentIndex >= 0) {
        currentBatchData.students[studentIndex].present = isPresent
      }
    }

    // Save updated batch data
    batchData.set(batchId, currentBatchData)

    // Broadcast update to all clients except sender
    socket.broadcast.emit("attendance:updated", {
      batchId,
      updates: currentBatchData.students,
    })
  })

  // Handle batch updates
  socket.on("batch:update", ({ batchId, data }) => {
    console.log(`Batch update for ${batchId}`)

    // Save batch data
    batchData.set(batchId, data)

    // Broadcast update to all clients except sender
    socket.broadcast.emit("batch:updated", {
      batchId,
      data,
    })
  })

  // Handle disconnection
  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id)

    // Remove user from users map
    users.delete(socket.id)

    // Broadcast updated user list
    io.emit("users:update", Array.from(users.values()))
  })
})

const PORT = process.env.PORT || 3001

server.listen(PORT, () => {
  console.log(`Socket.io server running on port ${PORT}`)
})
