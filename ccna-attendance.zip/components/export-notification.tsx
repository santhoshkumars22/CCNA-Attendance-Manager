"use client"

import { useState, useEffect } from "react"
import { X } from "lucide-react"
import { FileSpreadsheet } from "lucide-react"

interface ExportNotificationProps {
  reportType: string
  onClose: () => void
}

export default function ExportNotification({ reportType, onClose }: ExportNotificationProps) {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 10
      })
    }, 300)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (progress === 100) {
      const timer = setTimeout(() => {
        onClose()
      }, 2000)

      return () => clearTimeout(timer)
    }
  }, [progress, onClose])

  return (
    <div className="fixed bottom-4 right-4 w-80 rounded-lg bg-white p-4 shadow-lg">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-green-600" />
          <span className="font-medium">Exporting {reportType} Report</span>
        </div>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="mb-2 h-2 w-full overflow-hidden rounded-full bg-gray-200">
        <div className="h-full bg-green-600 transition-all duration-300" style={{ width: `${progress}%` }}></div>
      </div>

      <div className="text-sm text-gray-500">
        {progress < 100 ? "Preparing your download..." : "Download complete!"}
      </div>
    </div>
  )
}
