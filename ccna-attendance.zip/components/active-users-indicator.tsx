"use client"

import { useSocket } from "@/lib/socket"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function ActiveUsersIndicator() {
  const { activeUsers, isConnected } = useSocket()

  if (!isConnected) {
    return (
      <div className="flex items-center gap-2">
        <div className="h-2 w-2 rounded-full bg-yellow-500"></div>
        <span className="text-xs text-muted-foreground">Connecting...</span>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-2">
      <div className="h-2 w-2 rounded-full bg-green-500"></div>
      <span className="text-xs text-muted-foreground">Connected</span>

      <div className="ml-2 flex -space-x-2">
        <TooltipProvider>
          {activeUsers.slice(0, 5).map((user, index) => (
            <Tooltip key={user.id}>
              <TooltipTrigger asChild>
                <Avatar className="h-6 w-6 border-2 border-white">
                  <AvatarFallback className="text-xs bg-blue-500 text-white">
                    {user.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                <p>{user.name}</p>
              </TooltipContent>
            </Tooltip>
          ))}
          {activeUsers.length > 5 && (
            <Avatar className="h-6 w-6 border-2 border-white">
              <AvatarFallback className="text-xs bg-gray-500 text-white">+{activeUsers.length - 5}</AvatarFallback>
            </Avatar>
          )}
        </TooltipProvider>
      </div>
    </div>
  )
}
