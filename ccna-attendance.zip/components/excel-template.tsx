"use client"

import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export default function ExcelTemplate() {
  // This is a placeholder component for downloading the Excel template
  // In a real application, this would generate and download an Excel file

  const downloadTemplate = () => {
    // This would be handled by the backend
    console.log("Downloading Excel template")
    // The Excel file would be downloaded
  }

  return (
    <Button variant="outline" className="gap-2" onClick={downloadTemplate}>
      <Download className="h-4 w-4" />
      Download Template
    </Button>
  )
}
