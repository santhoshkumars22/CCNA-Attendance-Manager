"use client"

import { useState } from "react"
import { X, UserPlus, Upload, Calendar, Pencil, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import ExportNotification from "./export-notification"

interface BatchModalProps {
  batchId: string
  batchName: string
  sessionTime: string
  startDate: string
  endDate: string
  instructor: string
  isOpen: boolean
  onClose: () => void
}

export default function BatchModal({
  batchId,
  batchName,
  sessionTime,
  startDate,
  endDate,
  instructor,
  isOpen,
  onClose,
}: BatchModalProps) {
  const [activeTab, setActiveTab] = useState("students")
  const [exportNotification, setExportNotification] = useState<{ show: boolean; type: string } | null>(null)

  if (!isOpen) return null

  const students = [
    { id: "ST001", name: "Alex Johnson", email: "alex@example.com", phone: "555-123-4567", attendance: 92 },
    { id: "ST002", name: "Maria Garcia", email: "maria@example.com", phone: "555-987-6543", attendance: 78 },
    { id: "ST003", name: "James Wilson", email: "james@example.com", phone: "555-456-7890", attendance: 65 },
  ]

  const attendanceHistory = [
    { date: "Jul 15, 2023", present: 22, absent: 2, percentage: 92 },
    { date: "Jul 14, 2023", present: 20, absent: 4, percentage: 83 },
    { date: "Jul 13, 2023", present: 18, absent: 6, percentage: 75 },
  ]

  const studentsRequiringAttention = [
    { name: "James Wilson", attendance: 65, consecutiveAbsences: 3 },
    { name: "Sarah Brown", attendance: 60, consecutiveAbsences: 2 },
  ]

  const getProgressColorClass = (percentage: number) => {
    if (percentage >= 90) return "bg-green-500"
    if (percentage >= 75) return "bg-yellow-500"
    return "bg-red-500"
  }

  const handleExportReport = (reportType: "weekly" | "monthly" | "current") => {
    // This would be handled by the backend in a real application
    console.log(`Exporting ${reportType} attendance report for batch ${batchId}`)

    // Show export notification
    setExportNotification({
      show: true,
      type: reportType === "weekly" ? "Weekly" : reportType === "monthly" ? "Monthly" : "Current",
    })

    // In a real application, this would trigger a file download
    // For example:
    // window.location.href = `/api/batches/${batchId}/export?type=${reportType}`
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 pt-10">
      <div className="relative w-full max-w-6xl rounded-lg bg-white shadow-lg">
        {/* Header */}
        <div className="flex items-center justify-between bg-blue-600 px-6 py-4 text-white">
          <h2 className="text-2xl font-bold">{batchName}</h2>
          <button onClick={onClose} className="rounded-full p-1 hover:bg-blue-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Batch Info */}
        <div className="border-b px-6 py-4">
          <div className="space-y-1">
            <p className="text-lg">{sessionTime}</p>
            <p>
              {startDate} - {endDate}
            </p>
            <p>Instructor: {instructor}</p>
          </div>

          {/* Action Buttons */}
          <div className="mt-4 flex flex-wrap gap-3">
            <Button className="gap-2" variant="default">
              <UserPlus className="h-5 w-5" />
              Add Student
            </Button>
            <Button className="gap-2" variant="default" style={{ backgroundColor: "#4CAF50" }}>
              <Upload className="h-5 w-5" />
              Bulk Upload
            </Button>
            <Button className="gap-2" variant="default" style={{ backgroundColor: "#9C27B0" }}>
              <Calendar className="h-5 w-5" />
              Take Attendance
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="px-6 py-4">
          <TabsList className="mb-6 grid w-full grid-cols-3 border-b">
            <TabsTrigger
              value="students"
              className={`rounded-none border-b-2 px-4 py-2 ${
                activeTab === "students" ? "border-blue-600 text-blue-600" : "border-transparent"
              }`}
            >
              Students
            </TabsTrigger>
            <TabsTrigger
              value="attendance"
              className={`rounded-none border-b-2 px-4 py-2 ${
                activeTab === "attendance" ? "border-blue-600 text-blue-600" : "border-transparent"
              }`}
            >
              Attendance History
            </TabsTrigger>
            <TabsTrigger
              value="reports"
              className={`rounded-none border-b-2 px-4 py-2 ${
                activeTab === "reports" ? "border-blue-600 text-blue-600" : "border-transparent"
              }`}
            >
              Reports
            </TabsTrigger>
          </TabsList>

          {/* Students Tab */}
          <TabsContent value="students" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">Student List</h3>
              <div className="relative w-80">
                <Input type="search" placeholder="Search students..." className="pr-10" />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  <svg
                    className="h-5 w-5 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Attendance %</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>{student.id}</TableCell>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>{student.email}</TableCell>
                      <TableCell>{student.phone}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress
                            value={student.attendance}
                            className="h-2 w-24"
                            indicatorClassName={getProgressColorClass(student.attendance)}
                          />
                          <span>{student.attendance}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600">
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          {/* Attendance History Tab */}
          <TabsContent value="attendance" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">Attendance History</h3>
              <div className="flex items-center gap-2">
                <Input type="date" className="w-48" placeholder="dd/mm/yyyy" />
                <Button>Filter</Button>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Present</TableHead>
                    <TableHead>Absent</TableHead>
                    <TableHead>Attendance %</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendanceHistory.map((record) => (
                    <TableRow key={record.date}>
                      <TableCell>{record.date}</TableCell>
                      <TableCell>{record.present}</TableCell>
                      <TableCell>{record.absent}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress
                            value={record.percentage}
                            className="h-2 w-24"
                            indicatorClassName={getProgressColorClass(record.percentage)}
                          />
                          <span>{record.percentage}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button variant="link" className="text-blue-600">
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">Attendance Reports</h3>
              <div className="flex items-center gap-2">
                <Select defaultValue="7days">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">Last 7 days</SelectItem>
                    <SelectItem value="30days">Last 30 days</SelectItem>
                    <SelectItem value="90days">Last 90 days</SelectItem>
                    <SelectItem value="all">All time</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={() => handleExportReport("current")}>Export</Button>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              {/* Attendance Trend */}
              <div className="rounded-md border p-4">
                <h4 className="mb-4 text-lg font-medium">Attendance Trend</h4>
                <div className="h-64 w-full">
                  {/* Placeholder for chart */}
                  <div className="flex h-full items-end justify-between gap-2 pb-4">
                    {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => (
                      <div key={day} className="flex flex-1 flex-col items-center">
                        <div
                          className="w-full bg-blue-500"
                          style={{ height: `${Math.max(20, Math.random() * 80 + 20)}%` }}
                        ></div>
                        <div className="mt-2 text-xs">{day}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Attendance Distribution */}
              <div className="rounded-md border p-4">
                <h4 className="mb-4 text-lg font-medium">Attendance Distribution</h4>
                <div className="flex h-64 items-center justify-center">
                  {/* Circular progress indicator */}
                  <div className="relative flex h-48 w-48 items-center justify-center rounded-full border-[16px] border-blue-500">
                    <div
                      className="absolute top-0 h-[16px] w-[16px] origin-bottom rotate-[15deg] bg-red-500"
                      style={{ left: "calc(50% - 8px)" }}
                    ></div>
                    <div className="text-center">
                      <div className="text-4xl font-bold">85%</div>
                      <div className="text-sm text-gray-500">Average</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Export Options */}
            <div className="mt-6 rounded-md border p-4">
              <h4 className="mb-4 text-lg font-medium">Export Attendance Data</h4>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-lg border border-dashed p-4">
                  <h5 className="mb-2 font-medium">Weekly Report</h5>
                  <p className="mb-3 text-sm text-muted-foreground">
                    Export attendance data for the past week in Excel format
                  </p>
                  <Button variant="outline" className="w-full" onClick={() => handleExportReport("weekly")}>
                    Export Weekly Report
                  </Button>
                </div>
                <div className="rounded-lg border border-dashed p-4">
                  <h5 className="mb-2 font-medium">Monthly Report</h5>
                  <p className="mb-3 text-sm text-muted-foreground">
                    Export attendance data for the past month in Excel format
                  </p>
                  <Button variant="outline" className="w-full" onClick={() => handleExportReport("monthly")}>
                    Export Monthly Report
                  </Button>
                </div>
              </div>
            </div>

            {/* Students Requiring Attention */}
            <div className="mt-6 rounded-md border p-4">
              <h4 className="mb-4 text-lg font-medium">Students Requiring Attention</h4>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Attendance %</TableHead>
                    <TableHead>Consecutive Absences</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {studentsRequiringAttention.map((student) => (
                    <TableRow key={student.name}>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={student.attendance} className="h-2 w-24" indicatorClassName="bg-red-500" />
                          <span>{student.attendance}%</span>
                        </div>
                      </TableCell>
                      <TableCell>{student.consecutiveAbsences}</TableCell>
                      <TableCell>
                        <Button variant="link" className="text-blue-600">
                          Contact
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
        {/* Export Notification */}
        {exportNotification && exportNotification.show && (
          <ExportNotification reportType={exportNotification.type} onClose={() => setExportNotification(null)} />
        )}
      </div>
    </div>
  )
}
